require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const app = express();
app.use(cors({
    origin: 'https://mentaly-442312.et.r.appspot.com', // Ganti dengan URL frontend yang sudah di-deploy
    methods: ['GET', 'POST'],
  }));

// Setup Express

app.use(express.json());

// Koneksi ke database
const db = mysql.createConnection({
  host: process.env.DB_HOST,  // Gunakan IP publik Cloud SQL
  user: process.env.DB_USER,  // Username MySQL
  password: process.env.DB_PASSWORD,  // Password MySQL
  database: process.env.DB_NAME,  // Nama database
});

// Menghubungkan ke database
db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to the database.');
});

app.get('/', (req, res) => {
    res.send('Welcome to the Mental.ly API!');
  });

// Route untuk registrasi
// Route untuk registrasi
app.post('/register', (req, res) => {
    const { email, password, username } = req.body;
  
    // Validasi input
    if (!email || !password || !username) {
      return res.status(400).json({ message: 'Please provide email, password, and username' });
    }
  
    // Hash password sebelum menyimpannya ke DB
    bcrypt.hash(password, 10, (err, hashedPassword) => {
      if (err) {
        return res.status(500).json({ message: 'Error hashing password' });
      }
  
      // Insert data user ke database
      const query = 'INSERT INTO users (email, password, username) VALUES (?, ?, ?)';
      db.query(query, [email, hashedPassword, username], (err, result) => {
        if (err) {
          // Tampilkan detail error dari database untuk debugging
          console.error('Error during registration:', err);
          return res.status(500).json({ message: 'Error registering user', error: err.message });
        }
        return res.status(201).json({ message: 'User registered successfully' });
      });
    });
  });
  

// Route untuk login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Please provide email and password' });
  }

  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], (err, result) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching user' });
    }
    if (result.length === 0) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = result[0];

    // Membandingkan password yang diberikan dengan password yang ada di DB
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ message: 'Error comparing password' });
      }
      if (!isMatch) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }

      // Membuat token JWT
      const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

      return res.status(200).json({ message: 'Login successful', token });
    });
  });
});

// Jalankan server
const port = process.env.PORT || 4002;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
